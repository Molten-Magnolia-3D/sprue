Sprue mould: ring
Units: millimetres
Halves: lower (alignment keys) and upper (key sockets, spout, fill hole).
A runner was added because the spout would have missed the cavity.
