Sprue mould: bead
Units: millimetres
Halves: lower (alignment keys) and upper (key sockets, spout, fill hole).
The spout meets the cavity directly.
